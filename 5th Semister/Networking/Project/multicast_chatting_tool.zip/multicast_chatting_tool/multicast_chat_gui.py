import socket
import struct
import threading
import tkinter as tk
from tkinter import scrolledtext
from datetime import datetime
import platform
import os
import wave
import math

# --- Optional: playsound module for WAV notifications ---
try:
    from playsound import playsound
    SOUND_AVAILABLE = True
except ImportError:
    SOUND_AVAILABLE = False
    print("playsound module not found. Notification sound disabled. Install with: pip install playsound")

# --- Configuration ---
MCAST_GRP = '224.1.1.1'
MCAST_PORT = 5004
NOTIFICATION_SOUND = os.path.join("assets", "notification.wav")  # WAV file path

# --- Theme ---
THEME = "dark"  # "dark" or "light"

if THEME == "dark":
    BG_COLOR = "#2c2f33"
    TEXT_COLOR = "#ffffff"
    ENTRY_BG = "#23272a"
    ENTRY_FG = "#ffffff"
    BUTTON_BG = "#7289da"
    BUTTON_FG = "#ffffff"
else:
    BG_COLOR = "#ffffff"
    TEXT_COLOR = "#000000"
    ENTRY_BG = "#f0f0f0"
    ENTRY_FG = "#000000"
    BUTTON_BG = "#4CAF50"
    BUTTON_FG = "#ffffff"

def create_notification_sound():
    """Create a simple notification sound if it doesn't exist or is empty."""
    if not os.path.exists(NOTIFICATION_SOUND) or os.path.getsize(NOTIFICATION_SOUND) == 0:
        print("Creating notification sound...")
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(NOTIFICATION_SOUND), exist_ok=True)
            
            # Audio parameters
            sample_rate = 22050
            duration = 0.3  # 300ms
            frequency = 800  # 800 Hz
            
            # Generate a sine wave with envelope
            samples = []
            for i in range(int(sample_rate * duration)):
                t = i / sample_rate
                # Create envelope to avoid clicks
                envelope = 1.0
                if t < 0.05:  # fade in
                    envelope = t / 0.05
                elif t > duration - 0.05:  # fade out
                    envelope = (duration - t) / 0.05
                
                sample = envelope * math.sin(2 * math.pi * frequency * t)
                samples.append(int(sample * 32767))
            
            # Save as WAV file
            with wave.open(NOTIFICATION_SOUND, 'w') as wav_file:
                wav_file.setnchannels(1)  # Mono
                wav_file.setsampwidth(2)  # 16-bit
                wav_file.setframerate(sample_rate)
                
                # Convert to bytes
                import struct
                for sample in samples:
                    wav_file.writeframes(struct.pack('<h', sample))
            
            print(f"Notification sound created: {NOTIFICATION_SOUND}")
        except Exception as e:
            print(f"Failed to create notification sound: {e}")

class MulticastChatApp:
    def __init__(self, root, username):
        self.root = root
        self.username = username
        self.root.title(f"Multicast Chat - {username}")
        self.root.geometry("500x450")
        self.root.configure(bg=BG_COLOR)

        # --- Chat Area ---
        self.chat_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, state='disabled', bg=BG_COLOR, fg=TEXT_COLOR)
        self.chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # --- Entry + Send Button ---
        self.entry_frame = tk.Frame(root, bg=BG_COLOR)
        self.entry_frame.pack(fill=tk.X, padx=10, pady=(0,10))

        self.msg_entry = tk.Entry(self.entry_frame, bg=ENTRY_BG, fg=ENTRY_FG, width=60)
        self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.msg_entry.bind("<Return>", self.send_message)

        self.send_button = tk.Button(self.entry_frame, text="Send", bg=BUTTON_BG, fg=BUTTON_FG, command=self.send_message)
        self.send_button.pack(side=tk.RIGHT, padx=(5,0))

        # --- Networking Setup ---
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(('', MCAST_PORT))

        # Join multicast group
        mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

        # Start receiving messages
        threading.Thread(target=self.receive_messages, daemon=True).start()

    # --- Send Message ---
    def send_message(self, event=None):
        msg = self.msg_entry.get().strip()
        if msg:
            timestamp = datetime.now().strftime("%H:%M:%S")
            full_msg = f"[{timestamp}] [{self.username}] {msg}"
            self.sock.sendto(full_msg.encode('utf-8'), (MCAST_GRP, MCAST_PORT))
            self.msg_entry.delete(0, tk.END)

    # --- Receive Messages ---
    def receive_messages(self):
        while True:
            try:
                data, _ = self.sock.recvfrom(1024)
                message = data.decode('utf-8')
                self.display_message(message)
                self.play_notification()
            except:
                break

    # --- Display Message ---
    def display_message(self, message):
        self.chat_area.config(state='normal')
        self.chat_area.insert(tk.END, message + "\n")
        self.chat_area.config(state='disabled')
        self.chat_area.yview(tk.END)

    # --- Notification Sound ---
    def play_notification(self):
        if SOUND_AVAILABLE and os.path.exists(NOTIFICATION_SOUND):
            # Check if file is not empty before attempting to play
            if os.path.getsize(NOTIFICATION_SOUND) > 0:
                try:
                    threading.Thread(target=playsound, args=(NOTIFICATION_SOUND,), daemon=True).start()
                    return
                except Exception as e:
                    print(f"Error playing notification sound: {e}")
                    # Fall through to use system beep
            else:
                print("Notification sound file is empty, using system beep instead")
        
        # Fallback beep
        if platform.system() == "Windows":
            try:
                import winsound
                winsound.Beep(1000, 150)
            except Exception as e:
                print(f"Error playing system beep: {e}")

# --- Main ---
def main():
    # Ensure notification sound exists
    create_notification_sound()
    
    username = input("Enter your name: ")
    root = tk.Tk()
    app = MulticastChatApp(root, username)
    root.mainloop()

if __name__ == "__main__":
    main()
